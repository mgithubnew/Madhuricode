package utils;


import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
//import org.apache.poi.sl.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class TestUtils {

	public static Object[] testDataFeed(String testDataFile) throws IOException {

		int colCount = 0;
		int rowCount = 0;
		Object[][] output = readFromXLs(testDataFile, colCount, rowCount);
		// System.out.println(Arrays.deepToString(output));
		return output;

	}

	private static Object[][] readFromXLs(String testDataFile, int colCount, int rowCount) throws IOException {
		List<String> records = new ArrayList<String>();

		Workbook workbook = new XSSFWorkbook(testDataFile);
		Sheet sheet = workbook.getSheetAt(0);
		Iterator<Row> rowIterator = sheet.iterator();

		while (rowIterator.hasNext()) {
			colCount = 0;
			XSSFRow row = (XSSFRow) rowIterator.next();
			rowCount++;
			Iterator<Cell> cellIterator = row.iterator();

			while (cellIterator.hasNext()) {
				colCount++;
				Cell cell = cellIterator.next();
				switch (cell.getCellType()) {
				case  STRING:
					records.add(cell.getStringCellValue());
				}
			}
		}
		Object[][] output = generateDataArray(records, rowCount, colCount);
		return output;
	}

	private static Object[][] generateDataArray(List<String> dataList, int rowCount, int columnCount) {

		int k = 0;
		String[][] xlsData = new String[rowCount - 1][columnCount];
		for (int i = 0; i < rowCount - 1; i++) {

			for (int j = 0; j < columnCount; j++) {
				xlsData[i][j] = dataList.get(++k);
			}
		}
		return xlsData;
	}

}
package Feature;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Map;
import java.util.Set;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Row;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.IReporter;
import org.testng.ISuite;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import org.testng.xml.XmlSuite;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.testng.ISuite;

import org.testng.IReporter;
import org.testng.IResultMap;
import org.testng.ISuite;
import org.testng.ISuiteResult;
import org.testng.ITestContext;
import org.testng.ITestNGMethod;
import org.testng.xml.XmlSuite;

import utils.TestUtils;

public class AutomationOfFlipkart implements IReporter {
	public WebDriver driver;
	// public UIMap uimap;
	// public UIMap datafile;
	public String workingDir;

	// Declare An Excel Work Book
	HSSFWorkbook workbook;
	// Declare An Excel Work Sheet
	HSSFSheet sheet;
	// Declare A Map Object To Hold TestNG Results
	Map<String, Object[]> TestNGResults;
	// public static String driverPath = "C:\workspace\tools\selenium\";

	WebDriver driverOfFlipkart;
	WebDriverWait wait;

	@Test()
	public void init() throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", "G:\\setup\\chromedriver.exe");
		driverOfFlipkart = new ChromeDriver();
		driverOfFlipkart.manage().deleteAllCookies();
		driverOfFlipkart.manage().window().maximize();

		wait = new WebDriverWait(driverOfFlipkart, 100);
		driverOfFlipkart.get("https://www.flipkart.com");
		// TestNGResults.put("2", new Object[] { 1d, "Navigate to demo website", "Site
		// gets opened", "Pass" });

		Thread.sleep(5000);
	}

	@Test(dependsOnMethods = "searchProduct")
	public void productDetails()

	{
		driverOfFlipkart.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		WebElement productName = driverOfFlipkart.findElement(By.xpath("//*[@class='_2cLu-l']"));

		// System.out.println("Product Name:"+productName.getText());

		WebElement productPrice = driverOfFlipkart.findElement(By.xpath(" //*[@class='_1vC4OE']"));
		// System.out.println("ProductPrice:"+productPrice.getText());

		WebElement productRating = driverOfFlipkart.findElement(By.xpath("//*[@class='hGSR34']"));
		// System.out.println("Rating of product:"+productRating.getText());

	}

	@Test(dependsOnMethods = "init")
	public void login() {

		wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("_2zrpKA"))).sendKeys("8796129026");
		wait.until(ExpectedConditions
				.visibilityOfElementLocated(By.xpath("/html/body/div[2]/div/div/div/div/div[2]/div/form/div[2]/input")))
				.sendKeys("Flipkart@123");
		wait.until(ExpectedConditions.visibilityOfElementLocated(
				By.xpath("/html/body/div[2]/div/div/div/div/div[2]/div/form/div[3]/button"))).click();

	}

	@DataProvider
	public Object[] testData() throws IOException {
		// This path of xls can come from properties or from constants.
		return TestUtils.testDataFeed("G:\\eclipse\\MavenLearning\\src\\test\\java\\testData\\testData.xlsx");
	}

	@Test(dataProvider = "testData", dependsOnMethods = "login")
	public void searchProduct(String productName) {
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("LM6RPg"))).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("LM6RPg"))).clear();
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("LM6RPg"))).sendKeys(productName);
		Actions builder = new Actions(driverOfFlipkart);
		WebElement search = driverOfFlipkart.findElement(By.className("_2BhAHa"));
		builder.moveToElement(search).click().build().perform();

		// wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("_2BhAHa"))).click();
	}

	@Override()
    @Parameters({"arg0","suites","arg2"})

	@AfterClass
	public void generateReport(@Optional("IamOptional")List<XmlSuite> arg0, List<ISuite> suites, @Optional("IamOptional")String arg2) {

		
		for (ISuite ist : suites) {

			Map<String, ISuiteResult> resultMap = ist.getResults();

			Set<String> key = resultMap.keySet();

			for (String k : key) {

				ITestContext cntx = resultMap.get(k).getTestContext();

				System.out.println("Suite Name- " + cntx.getName() + "\n Report Directory- " + cntx.getOutputDirectory()
						+ "\n Test Suite Name- " + cntx.getSuite().getName() + "\n Start Date and Time of Execution- "
						+ cntx.getStartDate() + "\n End Date and Time of Execution- " + cntx.getEndDate());

				IResultMap failedTest = cntx.getFailedTests();

				Collection<ITestNGMethod> failedMethods = failedTest.getAllMethods();

				System.out.println("------Failed Test Case-----");

				for (ITestNGMethod imd : failedMethods) {

					System.out.println(
							"Test Case Name- " + imd.getMethodName() + "\n Description- " + imd.getDescription()
									+ "\n Priority- " + imd.getPriority() + "\n Date- " + new Date(imd.getDate()));
				}
				IResultMap passedTest = cntx.getPassedTests();

				Collection<ITestNGMethod> passedMethods = passedTest.getAllMethods();

				System.out.println("------Passed Test Case-----");

				for (ITestNGMethod imd1 : passedMethods) {

					System.out.println(
							"Test Case Name- " + imd1.getMethodName() + "\n Description- " + imd1.getDescription()
									+ "\n Priority- " + imd1.getPriority() + "\n Date- " + new Date(imd1.getDate()));
				}
			}
		}
	}
}

public class Employee extends Person{

	int eno;
	double salary;
	
	
	
	public Employee getEno() {
		return this;
	}
	public Employee setEno(int eno) {
		this.eno = eno;
		return this;
	}
	public double getSalary() {
		return salary;
	}
	public Employee setSalary(double salary) {
		this.salary = salary;
		return this;
	}
	
	
	
}


public class EmployeeImpl {

	public static void main(String[] args) {

		Employee e1 = new Employee();
		
		//e1.getEno();
//		e1.eno=1;
//		e1.name="Abc";
//		e1.salary=12345;
//		e1.address="Pune";
//		
//		
//		
//		
//		Employee e2 = new Employee();
//		
//		e2.eno=2;
//		e2.name="Pqr";
//		e2.salary=54321;
//		e2.address="Pune";
		
		
		System.out.println(e1.setEno(1).getEno().setSalary(100).getSalary());
		
		String str = "abc";
		
		System.out.println(str.toUpperCase().toLowerCase().length());
		
		
	}

}

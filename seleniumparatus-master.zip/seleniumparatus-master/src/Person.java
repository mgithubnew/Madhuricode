
public class Person {

	
	String name;
	String address;
	
	public Person getPerson(Person p) {
		
		
		return new Person();
		
		
	}
}

package pom;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.LoadableComponent;

public class LoginPage extends LoadableComponent<LoginPage> {

	WebDriver driver;

	@FindBy(name = "txtUsername")
	WebElement userName;

	@FindBy(name = "txtPassword")
	WebElement password;

	LoginPage(WebDriver driver) {

		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public void setLoginDetails(String user, String pass) {

		userName.sendKeys(user);
		password.sendKeys(pass);
	}

	@Override
	protected void load() {
		driver.get("https://opensource-demo.orangehrmlive.com/");
	}

	@Override
	protected void isLoaded() throws Error {
		// TODO Auto-generated method stub
		// assertEquals(driver.getTitle(), hompageTitle);
	}
}

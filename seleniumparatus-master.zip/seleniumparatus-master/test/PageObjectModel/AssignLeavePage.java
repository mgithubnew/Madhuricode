package PageObjectModel;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.LoadableComponent;
import org.openqa.selenium.support.ui.WebDriverWait;

public class AssignLeavePage extends LoadableComponent<AssignLeavePage> {

	@FindBy(id="welcome")
	WebElement welcomeText;
	
	@FindBy(linkText="Assign Leave")
	WebElement assignLeave;
	
//	@FindBy(id="assignleave_txtEmployee_empName")
//	WebElement empName;
	
	WebDriver driver;
	
	
	public AssignLeavePage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@Override
	protected void load() {
		
	}

	@Override
	protected void isLoaded() throws Error {
		// TODO Auto-generated method stub
		
		String actual = welcomeText.getText();
		
		assertEquals(actual, "Welcome Admin");
	}


	public void clickOnAssignLeaveOption() throws InterruptedException {
		
		WebDriverWait wait  = new WebDriverWait(driver, 10);
		
		wait.until(ExpectedConditions.elementToBeClickable(assignLeave));
		assignLeave.click();
		//empName.sendKeys("Shree");
	}
	// welcome
	//Assign Leave
	
	//assignleave_txtEmployee_empName
	
	//Shree
	
	
}

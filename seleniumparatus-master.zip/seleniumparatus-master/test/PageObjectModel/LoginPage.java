package PageObjectModel;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.LoadableComponent;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;



public class LoginPage extends LoadableComponent<LoginPage> {

	WebDriver driver;

	@FindBy(id = "txtUsername")
	WebElement userName;

	@FindBy(id = "txtPassword")
	WebElement passwordTextBox;

	@FindBy(id = "btnLogin")
	WebElement loginButton;

	public LoginPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public void login(String usename, String password) {

		userName.sendKeys(usename);

		passwordTextBox.sendKeys(password);

//		Actions builder = new Actions(driver);
//		builder.sendKeys(Keys.ENTER).build().perform();
		loginButton.click();

	}

	@Override
	protected void load() {
		driver.get("https://opensource-demo.orangehrmlive.com");
	}

	@Override
	protected void isLoaded() throws Error {
		// TODO Auto-generated method stub
		//Validations
		
		String actual = driver.getTitle();
		
		String expected ="OrangeHRM";
	
		assertEquals(actual, expected);
		
	}

}

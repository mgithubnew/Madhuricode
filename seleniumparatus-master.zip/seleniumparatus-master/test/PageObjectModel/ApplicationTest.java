package PageObjectModel;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class ApplicationTest {

	WebDriver driver;
	
	@BeforeClass
	public void init() {

		System.setProperty("webdriver.gecko.driver", "/Users/shreenivas_khedkar/Downloads/gecko");
		driver = new FirefoxDriver();
	}
	
	@Test(dataProvider="loginData")
	public void testLogin(String username,String password)
	 {
		LoginPage login = new LoginPage(driver);
		login.get();
		login.login(username, password);
	
	}
	
	@Test(dependsOnMethods="testLogin")
	public void testAssingLeave() throws InterruptedException {
		
		AssignLeavePage assignLeavePage = new AssignLeavePage(driver);
		assignLeavePage.get();
		assignLeavePage.clickOnAssignLeaveOption();
		
	}
	
	@DataProvider
	public String[][] loginData() {
		
		String[][] loginData = new String[1][2];
		
		loginData[0][0] = "Admin";
		loginData[0][1] = "admin123";
		
		return loginData;
 		
		
	}
	
}

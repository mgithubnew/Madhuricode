package javaBasics.Inheritence;

public class Implementation {

	public static void main(String[] args) {

		Circle c = new Circle();
		c.dim1 = 10;
		double result =c.area();
		System.out.println("Circle Area:"+result);
		
		Rectangle r  = new Rectangle();
		r.dim1 =10;
		r.dim2 = 20;
		
		double result2 =r.area();
		System.out.println("Rectangle Area:"+result2);
		
		Figure f = new Rectangle();
		
		//f.area();
		
		
		Operation o = new Rectangle();
		
		o.area();
		
		
	}
}

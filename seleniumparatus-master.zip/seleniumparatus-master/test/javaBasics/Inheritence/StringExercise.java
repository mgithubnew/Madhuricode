package javaBasics.Inheritence;

public class StringExercise {

	public static void main(String[] args) {

		String s1 = "modi";
		String s2 = "pappu";
		
		String s3 = new String("modi");
		
		if(s1.equals(s2)) {
			System.out.println("Equal");
		}
	}
}

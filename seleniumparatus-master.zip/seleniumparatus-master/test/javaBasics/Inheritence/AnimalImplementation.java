package javaBasics.Inheritence;

public class AnimalImplementation {

	public static void main(String[] args) {

		Animal a = new Animal();
		a.run();
		a.roar();
		
		Lion l = new Lion();
		l.color = "Brown";
		l.roar();
		
		Animal a2 = new Lion();
		a2.roar();
		
	}

}

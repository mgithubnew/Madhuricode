package javaBasics.Inheritence;

public class Lion extends Animal {

	public void roar() {
		
		System.out.println("Lion can roar!");
	}
}

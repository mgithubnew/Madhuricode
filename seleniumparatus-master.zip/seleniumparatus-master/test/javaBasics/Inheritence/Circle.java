package javaBasics.Inheritence;

public class Circle extends Figure{

	public double area() {
		return 3.14*dim1*dim1;
	}
}

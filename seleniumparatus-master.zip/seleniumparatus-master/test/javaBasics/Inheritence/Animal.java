package javaBasics.Inheritence;

public class Animal {

	String color;
	int noOfLegs;
	
	public void run() {
		System.out.println("Animal Can Run!");
	}
	
	public void roar() {
		
		System.out.println("Animal Can't Roar!");
	}
}

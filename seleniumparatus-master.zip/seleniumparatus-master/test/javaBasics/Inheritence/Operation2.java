package javaBasics.Inheritence;

public interface Operation2 {

	public double volume();
}

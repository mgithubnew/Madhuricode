package javaBasics.Inheritence;

public abstract interface Operation  {
	
	public double area();
	public abstract double area(double dimension);

}

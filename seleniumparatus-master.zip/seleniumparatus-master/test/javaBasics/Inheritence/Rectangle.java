package javaBasics.Inheritence;

public class Rectangle extends Figure implements Operation,Operation2{
	
	int result;
	


	@Override
	public double area() {
		// TODO Auto-generated method stub
		return 0;
	}
	
	public double area(double dimenstion) {
		return dimenstion;
		
		
	}



	@Override
	public double volume() {
		// TODO Auto-generated method stub
		return 0;
	}
	
	
}

package javaBasics;

interface Area {

	void calculateArea();

}

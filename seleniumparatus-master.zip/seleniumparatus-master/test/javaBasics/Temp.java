package javaBasics;

public class Temp {

	public static void main(String[] args) {

		String str1 = "Sachin";
		String str2 = new String("Sachin");
		String str3 = "Sachin";
		String str4 = new String("Sachin");
		
		if(str1.equalsIgnoreCase(str2)) {
			System.out.println("Both are equal");
		}
		else {
			System.out.println("Both are NOT equal");
		}
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}

}

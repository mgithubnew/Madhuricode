package javaBasics;

public class Car {

	int noofWheels;
	static boolean isCarStarted;

	public static void start() {

		isCarStarted = true;
	}

	public void stop() {
		isCarStarted = false;

	}
	public void run() {
		
		System.out.println("Run::"+isCarStarted);

	}
	
	public static void main(String[] args) {
		
		
//		c1.start();
//		System.out.println(c1.isCarStarted);
//		
//		c1.stop();
//		System.out.println(c1.isCarStarted);
		
		Car.isCarStarted=false;
		Car.start();
		
		Car c = new Car();
		
		c.run();
		
		
//		c2.run(); //true
//		c1.run();
//		
//		c2.stop();
//		c1.run();
		
	}

}

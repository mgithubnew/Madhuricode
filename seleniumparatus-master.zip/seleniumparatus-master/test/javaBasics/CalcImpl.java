package javaBasics;

public class CalcImpl {

	public static void main(String[] args) {

		Calculator c = new Calculator();
		
		
		
		String str;
		ArithmeticException e = new ArithmeticException();
	}

}

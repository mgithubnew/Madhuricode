package javaBasics;

import java.util.Scanner;

public class ArrayExamples {

	public static void main(String[] args) {

		// int a1[] = {10,20,30,40};


//		int a[] = new int[4];
//
//		//a[i]
//		a[0] = 10;
//		a[1] = 20;
//		
//		//a[2] = 30;
//		//a[3] = 40;
//
//		
//		for(int i =0;i< a.length ;i++ ) {
//			
//			System.out.println(a[i]);
//		}
//		
		String str[] ={"MI","CSK","RCB"};
		
		//System.out.println(str[4]);
		
		String str1[] = new String[4];
		
		str1[0] ="MI";
		str1[1] ="CSK;";
		str1[0] ="MI";
	
		str1[3] = "null";
		
//		for(int i=0;i<str1.length;i++) {
//			
//			System.out.println(str1[i]);
//		}
//		
//		for each values from str1 
//		 store one by one values in variable name
//		 print name
		 
			//Datatype	 variableName		: <<	from where the values needs to be printed >>
		for(String name : str1) {
			
			System.out.println(name);
		
		}
		
		
		//System.out.println(str1[0]);
	
//		for(int i =0 ;i< str.length;i++) {
//			
//			System.out.println(str[i]);
//		}
	
		
		// System.out.println(salman[2]);

	}

}

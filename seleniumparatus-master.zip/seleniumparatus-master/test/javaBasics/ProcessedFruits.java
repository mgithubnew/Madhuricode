package javaBasics;

public abstract class ProcessedFruits extends Mango  {

	public ProcessedFruits(String color, boolean isSeasonal) {
		super(color, isSeasonal);
		// TODO Auto-generated constructor stub
	}

}

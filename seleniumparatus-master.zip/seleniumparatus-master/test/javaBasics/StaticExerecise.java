package javaBasics;
public class StaticExerecise {

	static int a; //global declaration 500
	
	public static void main(String[] args) {
		System.out.println("Value is :" + a); //20
		printMe();
		sample();
		System.out.println("Value is :"+a);//20
	}

	private static void printMe() {
		System.out.println("Value of A is in Print:"+a);//0
	     a=300; 
	}
	
	private static void sample() {
		System.out.println("Value of A is in Print:"+a);//300
	     a=500; 
	}
}

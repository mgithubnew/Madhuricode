package javaBasics;

public abstract class Fruit {

	String color;
	boolean isSeasonal;
	
	double price=5;
	
	public Fruit(String color, boolean isSeasonal) {
		
		this.color=color;
		this.isSeasonal =isSeasonal;
	}
	
	public abstract void prepare();
	
	public Fruit prepareJuice() {
		
		
		System.out.println("Juice is prepared!");
		return null;
	}
	
	

}

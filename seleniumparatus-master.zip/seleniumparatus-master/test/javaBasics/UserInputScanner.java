package javaBasics;

import java.util.Scanner;

public class UserInputScanner {

	public static void main(String[] args) {

		Scanner scan = new Scanner(System.in);
		System.out.println("Please enter the number:");
		int no =scan.nextInt();
		System.out.println("Please enter another number:");
		int no2 = scan.nextInt();
		System.out.println("Entered Value is:"+no);
		System.out.println("Entered Value is:"+no2);
	}

}

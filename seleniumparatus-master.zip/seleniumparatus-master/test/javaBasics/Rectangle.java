package javaBasics;

public class Rectangle {


	


	
}

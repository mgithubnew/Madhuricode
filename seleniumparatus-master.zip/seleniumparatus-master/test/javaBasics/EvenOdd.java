package javaBasics;

public class EvenOdd {

	public static void main(String[] args) {

		int i = 1;
		
		do {
			System.out.println(i);
			i++;
		} while (i <= 50);

		for (int j = 1; j <= 50; j++) {
			System.out.println(i);
		}

		while (i <= 50) {
			System.out.println(i);
			i++;
		}
	}
}
//1. In do while - First excution and then condition checking
//2. In for - Initialization , condition and increment in one line
//3. While - condition and then excution ;no initialisation
//4. Lines of code is lesser for 'for' loop then while and do while
//5. Do while ends with semicolon

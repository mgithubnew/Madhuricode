package javaBasics;

public class CalculatorAssign {

	public static void main(String[] args) {

		double no1 = 10.5,no2 = 20.4;
		char char1 = 'h';
		char char2 = 'i';
		int addResult = addition(10,20);
		int threeNosResult=addThreeNos(10,20,30);			
		//System.out.println("Double Result:"+result);
		System.out.println("Int Result:"+addResult);
		System.out.println("Int Result:"+threeNosResult);
	}

	public static int addition(int no4, int no5) {
		int result = no4 + no5;
		return result;
	}
	public static int addThreeNos(int no4, int no5,int no6) {
		int result = no4 + no5+no6;
		return result;
	}
	
	public static double addition(double no6,double no7) {
		
		double result = no6+no7;
		return result;
	}
	
}

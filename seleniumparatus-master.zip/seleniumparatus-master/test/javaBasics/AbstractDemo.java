package javaBasics;

public class AbstractDemo {

	public static void main(String[] args) {

		Fruit mango = new Mango("yellow", true);
		
		mango.price=100;

		Fruit banana = new Banana("yellow", false);

		banana.price=10;
		mango.prepare();
		banana.prepare();
		
		mango.prepareJuice();
		banana.prepareJuice();
		
	

		
		
		// Fruit [] fruits = new Fruit[2];
		//
		// fruits[0] = mango;
		//
		// fruits[1] = banana;
		//
		// for(Fruit fruit : fruits) {
		//
		// fruit.prepare();
		// }

	}

}

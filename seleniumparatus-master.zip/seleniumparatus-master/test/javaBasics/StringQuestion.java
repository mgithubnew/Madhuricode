package javaBasics;

public class StringQuestion {

	public static void main(String[] args) {

		String str = new String("Hello");
		String str1 = "Hello";
		
		if(str==str1) {
			System.out.println("Strings Are Equal");
		}
		else {
			System.out.println("Strings Are NOT Equal");
		}
		
		String str2  = new String("Lata");
		
		str2.replace('L', 'B'); //Strings are immutable
		
		
		String str3  = "Shree";
		str3 ="Three";
		
		System.out.println(str3);
		
		
		
		int a =20;
		
		  a++;
		
		System.out.println(str2);
		System.out.println(a);
	}

}

package javaBasics;

public class Loops {

	public static void main(String[] args) {

		// While
		int i = 0;

		// while (i <= 10) {
		// i++;
		// System.out.println(i + " is my no.");
		//
		// }

//		for (; i <= 10;) {
//
//			System.out.println(i + " is my no.");
//			System.out.println(i + " is my no.");
//			System.out.println(i + " is my no.");
//			i++;
//			System.out.println(i + " is my no.");
//		}

//		do {
//
//			System.out.println(i + " is my no.");
//			
//			if(i==0)
//				break;
//		} while (i < 10);

	}

}

// For and While
// 1. In for,everything is in one line - intialisation,condition and increment
// 2. In for ,increment always happens at the end of the statement block
// 3. Programmers tends to forget increment in while

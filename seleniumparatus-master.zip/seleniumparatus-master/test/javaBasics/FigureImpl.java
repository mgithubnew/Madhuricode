package javaBasics;

public class FigureImpl {

	public static void main(String[] args) {

		
		Circle c = new Circle(10);
		

	 
		
	
		
	//	Area area = new Area();  -- not allowed
		
		//Rectangle rect = new Rectangle();
	}

}

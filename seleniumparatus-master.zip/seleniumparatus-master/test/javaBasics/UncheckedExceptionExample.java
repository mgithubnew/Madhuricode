package javaBasics;

import java.util.Scanner;

import javax.swing.plaf.synth.SynthSeparatorUI;

public class UncheckedExceptionExample {

	public static void main(String[] args)  {

		Scanner scan = new Scanner(System.in);

		int result = 0;
		String str = null;
		int a = scan.nextInt();
		int b = scan.nextInt();
		
		result = a / b;
		System.out.println(result);
	}
}

package javaBasics;

public class Loop {

	public static void main(String[] args) {
		// initialisation condition increment
		// for (int i = 2; i <= 10; ) {
		//
		// System.out.println(i);
		// i=i+2;
		// }
		int i = 2;
		while (i < 10) {
			System.out.println(i);
			i = i + 2;

		}
	}
}

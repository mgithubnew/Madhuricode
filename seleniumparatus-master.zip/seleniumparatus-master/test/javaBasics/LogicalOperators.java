package javaBasics;

public class LogicalOperators {

	public static void main(String[] args) {

		int a = 20, b = 25;

		if (a == 10 && b == 20) {

			System.out.println("Inside If..");

		} else {
			System.out.println("Outside If..");
		}

	}

}
//short -circuit evaluation

// Truth Table -AND

// T T T
// F T F
// T F F
// F F F
//
//// Truth Table - OR
//
// T T T
// F T T
// T F T
// F F F

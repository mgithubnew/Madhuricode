package javaBasics;

public class UserInput {

	public static void main(String[] args) {

		 String no1 = args[0];
		 String no2 = args[1];
		 String no3 = args[2];
		 String no4 = args[3];
		
		String c = no1+no2;
		
		System.out.println("Result is :"+c);
		System.out.println("Result is :"+no3+no4);
		
	}

}

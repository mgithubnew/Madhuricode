package javaBasics;

public class StringExamples {

	public static void main(String[] args) {

		// Scanner scan = new Scanner(System.in);
		String name2 = "10";
		int a =10;
		String str = new String("Sachin"); // constructor

		String name3 = new String("Rahul");
		
		String name4 =name3.intern();
		
		int array [] = {1,2,3,4};

		String name = str.intern();

		
		String record ="shree,kothrud,pune";

		String [] tokens =record.split(",");
				
				
				
		if (name3==name4) {
			
			System.out.println("Equal");
		}
		// String interning
	//	System.out.println(str);

		// if (name.equals(name2)) {
		// System.out.println("Strings are EQUAL");
		// } else {
		// System.out.println("Strings are NOT EQUAL");
		// }
		// New - Memory is allocated in Heap
		// String literal pool

	}
}

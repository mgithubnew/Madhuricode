package javaBasics;

public class ScientificCalculator extends Calculator {

	
	public double sin(int a) {

		return Math.sin(a);

	}
	
//	public int addition() {
//		
//		System.out.println("In B's Addition");
//		return a*b;
//		
//		
//	}
	
}

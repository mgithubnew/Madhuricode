package javaBasics;

public abstract class Vegetable extends Fruit  {

	public Vegetable(String color, boolean isSeasonal) {
		super(color, isSeasonal);
		// TODO Auto-generated constructor stub
	}
	
	

}

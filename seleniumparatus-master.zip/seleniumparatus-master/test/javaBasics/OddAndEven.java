package javaBasics;

import java.util.Scanner;

public class OddAndEven {

	public static void main(String[] args) {

		// 1.User Input
		Scanner scan = new Scanner(System.in);
		System.out.println("Please enter the no=>");
		int inputNo = scan.nextInt();
		int no = 0;

		// 2. Reach till the no entered by user
//		while (no < inputNo) {
//
//			if (no % 2 == 0) {
//				System.out.println(no + " is even");
//			} else {
//				System.out.println(no + " is odd");
//			}
//			no++;
//		}
		
		for(int i=1; i< inputNo;i++) {
			i=i+1;
			System.out.println(i + " is even");
			
		}
		for(int i=0; i< inputNo;i++) {
			i=i+1;
			System.out.println(i + " is odd");
			
		}

		// 3. Every no till the no entered by user has to be checked for even or odd
		// a. No can be divided and check the remainder
		// if the remainder is 0 then no is even else odd
		   //b.

	}

}

package javaBasics;

public class Figure  {

	int dim1, dim2;
	
	Figure(int dim1){
		
		this.dim1= dim1;
	}
	
	
	
}

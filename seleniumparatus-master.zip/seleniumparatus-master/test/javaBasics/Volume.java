package javaBasics;

public interface Volume{

	public void calculateVolume();
}

package javaBasics;

public class CalculatorExample {

	int a, b;

	CalculatorExample(int a, int b) {

		this.a = a;
		this.b = b;
	}

	void addition() {

		System.out.println("Addition is :" + (a + b));
	}

	public static void main(String[] args) {

		CalculatorExample calculator = new CalculatorExample(10, 20);
		
		calculator.addition();

	}
}

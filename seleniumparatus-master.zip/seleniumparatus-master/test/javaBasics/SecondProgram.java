package javaBasics;

public class SecondProgram {

	 public static void main(String[] args) {

		System.out.println("This is my second program");
	}
	
}

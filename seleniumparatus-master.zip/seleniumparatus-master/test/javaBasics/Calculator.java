package javaBasics;

public class Calculator implements Area {

	int a;
	int b;

	// Calculator(int a, int b) {
	//
	// this.a = a;
	// this.b = b;
	// }

	public int addition() {

		System.out.println("In A's Addition");
		int c = a + b;

		return c;
	}

	public int substraction() {

		int c = b - a;

		return c;
	}

	public int multiplication() {

		int c = a * b;

		return c;
	}

	public int division() {

		int c = a / b;

		return c;
	}

	@Override
	public void calculateArea() {
		// TODO Auto-generated method stub
		
	}

}

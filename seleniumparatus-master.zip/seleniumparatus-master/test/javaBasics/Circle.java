package javaBasics;

public class Circle extends Figure {

	Circle(int dimension) {
		super(dimension);
		System.out.println("In Circle's Constructor");
		
		
	}

}

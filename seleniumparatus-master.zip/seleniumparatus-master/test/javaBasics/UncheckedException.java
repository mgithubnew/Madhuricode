package javaBasics;

public class UncheckedException {

	public static void main(String[] args) {

		int a = 10;
		int b = 0;
		int c = 0;
		

		try {
			c = a / b;

		} 
		catch(Exception e) {
			
			System.out.println("In exception:"+e);
		}
		finally {
			
			System.out.println("I am in finally");
		}
		
	}

}

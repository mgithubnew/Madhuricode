package javaBasics;

public class Mango extends Fruit {

	public Mango(String color, boolean isSeasonal) {
			
		super(color,isSeasonal);
	}

	@Override
	public void prepare() {
		 System.out.println("Cut the Mango");
		
	}

}

package javaBasics;

public class Banana extends Fruit {

	public Banana(String color, boolean isSeasonal) {
		super(color, isSeasonal);
	}

	@Override
	public void prepare() {
		 System.out.println("Peal the Banana");
		
	}
	
	

}

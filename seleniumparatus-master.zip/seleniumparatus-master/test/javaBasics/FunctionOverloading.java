package javaBasics;

public class FunctionOverloading {

	static int i=10;
	static int j=20;

	public static void main(String[] args) {

		addition();
	}
	public static int addition() {

		System.out.println(i + j);
		i = i + 1;// 11
		return i++;
	}

	// private static int addition(int i, int j) {
	// System.out.println("I:" + i);//11 2
	// System.out.println("J:" + j);//21 21
	// i++; //not printing 12 3
	// j++; //not printing 22 22
	// System.out.println("Changed I:" + i);//12 3
	// System.out.println("Changed J:" + j);//22 22
	//
	// System.out.println("Multiplication is:" + multiplication()); //2 2
	// return multiplication();
	// }
	// private static int multiplication() {
	// int i = 10, j = 20;
	// int k = i * j; // not printing 200
	// System.out.println("K:" + k); //200 ,200 ,200 ,200
	// return j / i; //not printing 2 2
	// }
}

package javaBasics;

public class Functions {

	public static void main(String[] args) { // caller

		int x = 10, y = 20;
		double z = 35.5;
		System.out.println("X is:" + x);
		double c = addition(x, y, z); // calling a function

		System.out.println("Addition is:" + c);

	}

	public static double addition(int a, int b, double d) { // function defination //callee

		double c = a + b + d;
		fun();
		return c;

	}

	
	public static void fun() {
		// TODO Auto-generated method stub

	}

	public static double addition(float a, float b, float c) {

		return a + b + c;
	}

}

package demo;

import java.util.concurrent.TimeUnit;

import org.apache.xerces.impl.dv.util.Base64;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

public class FirstProgram {

	public static void main(String[] args) {

		System.setProperty("webdriver.gecko.driver", "/Users/shreenivas_khedkar/Downloads/gecko");

		WebDriver driver = new FirefoxDriver();
		
		Wait<WebDriver> wait = new FluentWait<WebDriver>(driver)
			    .withTimeout(30, TimeUnit.SECONDS)
			    .pollingEvery(5, TimeUnit.SECONDS)
			    .ignoring(MyCustomException.class);
		
			

		driver.get(Constants.URL);
		driver.findElement(By.id(Constants.EMAIL)).sendKeys(Constants.USERNAME);
		driver.findElement(By.id("pass")).sendKeys(new String(Base64.decode("emVicmExMjM=")));
		driver.findElement(By.id("loginbutton")).click();

	}
	
	

}

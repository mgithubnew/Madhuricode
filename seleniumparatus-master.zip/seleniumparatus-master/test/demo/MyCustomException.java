package demo;

public class MyCustomException extends RuntimeException {

	MyCustomException(String message){
		
		super(message);
	}	

}

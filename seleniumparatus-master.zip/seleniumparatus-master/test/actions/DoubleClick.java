package actions;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.interactions.Actions;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class DoubleClick {
	WebDriver driver;
	@Before
	public void setUp() {
		//System.setProperty("webdriver.gecko.driver", "/Users/shreenivas_khedkar/Downloads/gecko20/geckodriver");
		System.setProperty("webdriver.gecko.driver", "/Users/shreenivas_khedkar/Downloads/geckodriver");
		// Open browser
		driver = new FirefoxDriver();

		/*System.setProperty("webdriver.ie.driver", "test\\resources\\IEDriverServer.exe");
		WebDriver driver = new InternetExplorerDriver();*/
		driver.get("http://artoftesting.com/sampleSiteForSelenium.html");
	}
	
	
	
	@Test
	public void testDoubleClick()
	{
		
			
		WebElement message = driver.findElement(By.id("dblClkBtn"));
		
		
		Actions builder = new Actions(driver);
		builder.doubleClick(message).build().perform();
		
		//Sleep is introduced below is purely for demo purpose so you can see 
		// the effect of action on the page before it closes and not to be used
		//in actual test cases as it delays the overall test execution
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		Alert alert = driver.switchTo().alert();
		
		assertEquals("Hi! Art Of Testing, Here!", alert.getText());
		
		alert.accept();
		
	}
}
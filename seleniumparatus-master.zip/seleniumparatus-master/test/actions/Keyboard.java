package actions;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class Keyboard {

	WebDriver driver;
	@BeforeClass
	public void setup() {
	System.setProperty("webdriver.gecko.driver", "/Users/shreenivas_khedkar/Downloads/gecko20/geckodriver");
	// Open browser
	driver = new FirefoxDriver();

	driver.get("http://opensource.demo.orangehrmlive.com/");
	
	}
	
	@Test
	public void testLogin() {
		
		driver.findElement(By.id("txtUsername")).sendKeys("Admin");
		driver.findElement(By.id("txtPassword")).sendKeys("admin");
		
		Actions builder = new Actions(driver);
		
		builder.sendKeys(Keys.ENTER).build().perform();
		
		
	}
	
	
	
	
}

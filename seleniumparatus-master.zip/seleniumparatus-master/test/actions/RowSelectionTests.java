package actions;
import static org.junit.Assert.*;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

//import com.thoughtworks.selenium.Wait;

public class RowSelectionTests {
	
	WebDriver driver;

	@Before
	public void setUp() throws InterruptedException
	{
		System.setProperty("webdriver.chrome.driver", "/Users/shreenivas_khedkar/Downloads/chromedriver2.37/chromedriver");
		// Open browser
		driver = new ChromeDriver();
		/*System.setProperty("webdriver.gecko.driver", "test\\resources\\geckodriver.exe");
		driver = new FirefoxDriver();*/
		driver.get("http://component-showcase.icesoft.org/component-showcase/showcase.iface");
		driver.findElement(By.linkText("Table")).click();
		//driver.manage().timeouts().implicitlyWait(0, TimeUnit.SECONDS);
		WebDriverWait wait = new WebDriverWait(driver,30);
		
		Thread.sleep(3000);
		JavascriptExecutor jsx = (JavascriptExecutor) driver;

		jsx.executeScript("window.scrollBy(0,900)", "");
		Thread.sleep(3000);
		WebElement rowSelection = driver.findElement(By.linkText("Row Selection"));
	//	driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		rowSelection.click();
		//driver.findElement(By.linkText("Row Selection")).click();
		//assignment - find alternate locator for 'multiple' radio button
		WebElement selectMultiple = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//table[@class='iceSelOneRb']/tbody/tr/td[2]/label")));
		selectMultiple.click();
		//driver.findElement(By.xpath("//table[@class='iceSelOneRb']/tbody/tr/td[2]/label")).click();
	}

	@Test
	public void testRowSelectionUsingControlKey() {
		
		List<WebElement> tableRows = driver.findElements(By.xpath("//table[@class='iceDatTbl']/tbody/tr"));
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
		//Select second and fourth row from Table using Control Key.
		//Row Index start at 0
		Actions builder = new Actions(driver); //builder design pattern
		//builder design pattern
		builder.click(tableRows.get(1)).keyDown(Keys.COMMAND).click(tableRows.get(3)).click(tableRows.get(5)).keyUp(Keys.COMMAND).build();//
		builder.perform();//Actual action happens on the page
		builder.keyDown(Keys.SHIFT).click(tableRows.get(7)).keyUp(Keys.SHIFT).build();
		builder.perform();
		
		//Verify Selected Row Table shows two rows selected
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		List<WebElement> rows = driver.findElements(By.xpath("//div[@class='icePnlGrp exampleBox']/table[@class='iceDatTbl']/tbody/tr"));
		assertEquals(3,rows.size());
		
	//	WebElement someElement = driver.findElement(By.name("ome"));
	
	}
	
	//@Test
	public void testRowSelectionUsingShiftKey() throws InterruptedException {
		
		List<WebElement> tableRows = driver.findElements(By.xpath("//table[@class='iceDatTbl']/tbody/tr"));

		//Select first row to fourth row from Table using Shift Key
		//Row Index start at 0
		Actions builder = new Actions(driver);
		builder.click(tableRows.get(0)).keyDown(Keys.SHIFT)
				.click(tableRows.get(1))
				.click(tableRows.get(2))
				.click(tableRows.get(3))
				.keyUp(Keys.SHIFT)
				.build().perform();
		Thread.sleep(10000);
		List<WebElement> rows = driver.findElements(By.xpath("//div[@class='icePnlGrp exampleBox']/table[@class='iceDatTbl']/tbody/tr"));
		assertEquals(4,rows.size());
	}
	
	@After
	public void tearDown()
	{
		//driver.quit();
	}

}

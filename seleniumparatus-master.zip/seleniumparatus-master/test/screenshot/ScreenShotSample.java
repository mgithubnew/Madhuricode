package screenshot;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

public class ScreenShotSample {

	WebDriver driver;
	int countOfScreenshots ;

	@BeforeSuite
	public void setUp() {

		System.setProperty("webdriver.gecko.driver", "/Users/shreenivas_khedkar/Downloads/geckodriver");
		// Open browser
		driver = new FirefoxDriver();

		driver.get("https://google.com");

	}

	@Test
	public void should_create_screenshot() throws IOException {

		try {

			driver.findElement(By.id("cart")).click();
			
			driver.get("facebook.com");
			
			driver.navigate().to("flipkart");
			
			takeScreenshot("C:\\Screenshots\"+++"+".png");
			
			
			takeScreenshot("C:\\Screenshots\"+countOfScreenshots++"+".png");
			
		}

		catch (NoSuchElementException e) {

			
			// 1.Casting

			TakesScreenshot capture = (TakesScreenshot) driver;

			// 2.Taking screenshot

			File actualScreenshot = capture.getScreenshotAs(OutputType.FILE);

			// 3.Create New file for copying

			File myFile = new File("screenshot.png");

			// 4.Copy screenshot to myfile

			FileUtils.copyFile(actualScreenshot, myFile);

		}

	}

	private void takeScreenshot(String path) throws IOException {
		// 1.Casting

		TakesScreenshot capture = (TakesScreenshot) driver;

		// 2.Taking screenshot

		File actualScreenshot = capture.getScreenshotAs(OutputType.FILE);

		// 3.Create New file for copying

		File myFile = new File(path);

		// 4.Copy screenshot to myfile

		FileUtils.copyFile(actualScreenshot, myFile);
	}

}

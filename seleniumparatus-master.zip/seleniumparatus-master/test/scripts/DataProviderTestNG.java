package scripts;

import org.testng.annotations.Test;
import org.testng.annotations.DataProvider;
import org.testng.annotations.BeforeClass;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterClass;

public class DataProviderTestNG {

	WebDriver driver;

	@Test(dataProvider = "loginData")
	public void login(String username, String password) throws InterruptedException {

		Thread.sleep(3000);
		WebElement usernameTextBox = driver.findElement(By.id("txtUsername"));
		usernameTextBox.clear();
		usernameTextBox.sendKeys(username);
		WebElement passwordTextBox = driver.findElement(By.id("txtPassword"));
		passwordTextBox.clear();
		passwordTextBox.sendKeys(password);
	}

	@DataProvider
	public Object[][] loginData() {

		Object loginData[][] = new Object[3][2];

		loginData[0][0] = "u1";
		loginData[0][1] = "p1";

		loginData[1][0] = "u2";
		loginData[1][1] = "p2";

		loginData[2][0] = "Admin";
		loginData[2][1] = "admin";
		

		return loginData;
	}

	@BeforeClass
	public void beforeClass() {
		System.setProperty("webdriver.gecko.driver", "/Users/shreenivas_khedkar/Downloads/geckodriver");
		driver = new FirefoxDriver();
		driver.get("http://opensource.demo.orangehrmlive.com/");
	}

	@AfterClass
	public void afterClass() {

		driver.quit();
	}

}

package scripts;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class JunitExercise {

	@BeforeClass
	public void setUp() throws Exception {
		System.out.println("In Before::setUp");
	}

	

	@Test
	public void test2() {
		System.out.println("In testB");
	}

	@Test
	public void test1() {
		System.out.println("In testA");
	}
	
	
	@AfterClass
	public void tearDownA() throws Exception {
		System.out.println("In After::tearDown");
	}

}

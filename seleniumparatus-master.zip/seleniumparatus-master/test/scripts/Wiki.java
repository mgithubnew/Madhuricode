package scripts;

import static org.junit.Assert.assertTrue;
import static org.testng.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Wiki {

	public static void main(String[] args) throws InterruptedException {
		
		System.setProperty("webdriver.gecko.driver", "/Users/shreenivas_khedkar/Downloads/geckodriver");
		//Open browser
		WebDriver driver = new FirefoxDriver();
		//Open wiki
		driver.get("https://www.wikipedia.org");
		//driver.manage().window().maximize();
		//driver.manage().window().setSize(new Dimension(1200, 864));
		
		//Finding an element and click on it -English
		driver.findElement(By.id("js-link-box-en")).click();
		
		System.out.println(driver.findElement(By.tagName("body")).getText());
		System.out.println("page source:"+driver.getPageSource());
		
		Thread.sleep(3000);
		//Search selenium
		driver.findElement(By.id("searchInput")).sendKeys("Selenium");
		Thread.sleep(3000);
		//Click button
		driver.findElement(By.id("searchButton")).click();
		//Validation of title -Getting Actual Title
		String actualTitle=driver.getTitle();
		if(actualTitle.equals("Wikipedia, the free encyclopedia1")) {
			System.out.println("Happy Holi!");
		}
		else {
			System.out.println("UnHappy Holi!");
		}
		Thread.sleep(3000);
		String firstHeading=driver.findElement(By.id("firstHeading")).getText();
		
		assertEquals(firstHeading, "Selenium");
		//assertTrue(message, condition);
		
//		if(firstHeading.equals("Selenium")) {
//			System.out.println("Selenium Text is verified!");
//		}
//		else {
//			System.out.println("Selenium Text is not found!");
//		}
		driver.quit();
	}

}

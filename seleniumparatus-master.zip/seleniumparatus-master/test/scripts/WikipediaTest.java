package scripts;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class WikipediaTest {
	WebDriver driver;

	@BeforeClass
	public void setUp() throws Exception {

		//System.setProperty("webdriver.gecko.driver", "/Users/shreenivas_khedkar/Downloads/geckodriver");
		// Open browser
		driver = new FirefoxDriver();

		// driver.navigate().refresh();
		//
		// driver.getCurrentUrl();
		// driver.get("facebook");
		// //driver.navigate().to("flipkart");
		// driver.navigate().back();
		//
		// driver.getCurrentUrl();
		//
		// driver.manage().window().setSize(new Dimension(1024,768));
		//
		//
		// driver.findElement(By.id("table")).findElement(By.id("tr"));

		// System.out.println("In SetUp");
	}

	@AfterClass
	public void tearDown() throws Exception {
		driver.quit();
		// System.out.println("In TearDown");

	}

	@Test
	public void testA() {
		System.out.println("In TestA");
	}

	@Test
	public void searchOnWikipedia() throws InterruptedException {

		// System.out.println("In TestB");

		driver.get("https://www.wikipedia.org");
		// Finding an element and click on it
		driver.findElement(By.id("js-link-box-en")).click();
		Thread.sleep(3000);

		// Validation of title -Getting Actual Title
		String actualTitle = driver.getTitle();
		// if (actualTitle.equals("Wikipedia, the free encyclopedia1")) {
		// System.out.println("Happy Holi!");
		// } else {
		// System.out.println("UnHappy Holi!");
		// }

		assertEquals("Wikipedia, the free encyclopedia", actualTitle);
		// Search selenium
		driver.findElement(By.id("searchInput")).sendKeys("Selenium");
		Thread.sleep(3000);
		// Click button
		driver.findElement(By.id("searchButton")).click();

		Thread.sleep(3000);
		String firstHeading = driver.findElement(By.id("firstHeading")).getText();
		if (firstHeading.equals("Selenium")) {
			System.out.println("Selenium Text is verified!");
		} else {
			System.out.println("Selenium Text is not found!");
		}

	}

}

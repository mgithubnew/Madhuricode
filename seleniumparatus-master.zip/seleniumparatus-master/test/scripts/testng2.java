package scripts;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.AfterClass;

public class testng2 {
  @Test(groups="Regression",dependsOnGroups="E2E")
  public void f1() {
	  System.out.println("testng2::f1:in test");
  }
  @Test
  public void f2() {
	  System.out.println("testng2::f2:in test");
  }
  @BeforeClass
  public void beforeClass() {
	  System.out.println("testng2::in beforeClass");
  }

  @AfterClass
  public void afterClass() {
	  System.out.println("testng2::in afterClass");
  }

}

package scripts;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;

import static org.testng.Assert.assertFalse;
import static org.testng.Assert.assertTrue;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;

public class testng1 {

	WebDriver driver;

	@Parameters({"Browser","Username"})
	@Test // (expectedExceptions= AssertionError.class)
	// @Optional("ff")String browserName,String username,String password
	public void login(String browserName,String userName) {

		System.out.println("BrowserName:"+browserName);
		//
		 System.out.println("Username:"+userName);
		 //System.out.println("Password:"+password);

		 //driver.get(url);
		// driver.findElement(By.xpath("usename")).sendKeys(username);
		 switch(browserName) {
		
		 case "ch" :
		 // System.setProperty(key, value)
		 driver= new ChromeDriver();
		 break;
		
		 case "ff" :
		 // System.setProperty(key, value)
		 driver= new FirefoxDriver();
		 break;

		
		 }
		 driver = new FirefoxDriver();

		System.out.println("testng1::in login test");

		// assertFalse(false);

	}

	@BeforeClass
	public void beforeClass() {
		System.out.println("testng1::in beforeClass");
	}

	@AfterClass
	public void afterClass() {
		System.out.println("testng1::in afterClass");
	}

	@Test (groups={"E2E"})
	public void addToCart() {

		System.out.println("testng1::in addCart test");
	}

	@Test  (groups={"Regression"})
	public void searchItem() {

		System.out.println("testng1::in searchItem test");
	}
}

package scripts.commonscripts;

import org.testng.annotations.Test;

import common.TestDataProvider;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.AfterSuite;

public class AllTestNGAnnotations extends TestDataProvider{

	@Test(dataProvider="provideTestData")
	public void login(String firstName, String lastName) {
		
		
		System.out.println("FirstName:"+firstName);
		System.out.println("LastName:"+lastName);
	}

	
}

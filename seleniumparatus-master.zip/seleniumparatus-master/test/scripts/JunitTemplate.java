package scripts;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class JunitTemplate {

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		
		System.out.println("In Before Class");
	}
	
	
	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		System.out.println("In tearDownAfterClass");
	}

	@Before
	public void setUp() throws Exception {
		System.out.println("In Before Method::setUp");
	}

	@After
	public void tearDown() throws Exception {
		System.out.println("In After Method::tearDown");
	}

	@Test
	public void testA() {
		System.out.println("In testA");
	}
	@Test
	public void testB() {
		System.out.println("In testB");
	}


}

package scripts;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

public class WebTable {

	public static void main(String[] args) {

		System.setProperty("webdriver.gecko.driver", "/Users/shreenivas_khedkar/Downloads/geckodriver");
		//Open browser
		WebDriver driver = new FirefoxDriver();
		
		driver.get("http://cookbook.seleniumacademy.com/Locators.html");
		
		WebElement table = driver.findElement(By.xpath("//*[@class='cart-info']/table"));
		
		//Get the rows and cols of a table
		List<WebElement> rows=table.findElements(By.tagName("tr"));
		List<WebElement> cols=table.findElements(By.xpath("//*[@class='cart-info']/table/thead//td"));
		
		System.out.println("Rows:"+rows.size());
		System.out.println("Cols:"+cols.size());
		
		for(int  i =0;i<rows.size();i++ ) {
		
			for (int j=0;j<cols.size();j++) {
			WebElement searchRow = getTableRow(table,i);
			WebElement searchCol = getCol(searchRow,j);
			System.out.println(getTextFromCol(searchCol));
			}
		}
		
//		WebElement editRow=getTableRow(table,1);
//		WebElement editCol = getCol(editRow,0);
//		
//		editCol.findElement(By.tagName("input")).clear();
//		editCol.findElement(By.tagName("input")).sendKeys("4");
		
	}

	private static String getTextFromCol(WebElement searchCol) {
		return searchCol.getText();
	}

	private static WebElement getCol(WebElement searchRow,int colIndex) {
		WebElement searchCol = searchRow.findElements(By.tagName("td")).get(colIndex);
		return searchCol;
	}

	private static WebElement getTableRow(WebElement table,int rowIndex) {
		WebElement searchRow=table.findElements(By.tagName("tr")).get(rowIndex);
		return searchRow;
	}

}

package scripts;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;

import static org.testng.Assert.assertFalse;
import static org.testng.Assert.assertTrue;

import org.testng.annotations.AfterClass;

public class SampleTestNG {

	@Test()
	public void login() {
		System.out.println("In SampleTestNG Test Method::login");
		
		assertTrue(true);
	}

	@BeforeClass
	public void beforeClass() {
		System.out.println("In SampleTestNG Before Class");
	}

	@Test(dependsOnMethods= {"login"})
	public void addToCart() {
		System.out.println("In SampleTestNG Test Method::addToCart");
	}

	@AfterClass
	public void afterClass() {
		System.out.println("In SampleTestNG After Class");
	}

}

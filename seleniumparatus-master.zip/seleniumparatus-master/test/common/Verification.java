package common;

import static org.testng.Assert.assertEquals;

public class Verification {

	
	public static void textEquals(String actual,String expected) {
		 assertEquals(actual, expected);
	}
}

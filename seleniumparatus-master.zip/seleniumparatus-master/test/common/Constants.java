package common;

public class Constants {
	
	public  final String FINISH = "finish";
	
	public static String VERIFICATION_BMI_LOG = "Verification of bmi is completed";

}

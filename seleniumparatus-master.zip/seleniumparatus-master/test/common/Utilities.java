package common;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;

public class Utilities {

	public static void takeScreenshot(WebDriver driver, String filepath) throws IOException {
		// 1.Casting

		TakesScreenshot capture = (TakesScreenshot) driver;

		// 2.Taking screenshot

		File actualScreenshot = capture.getScreenshotAs(OutputType.FILE);

		// 3.Create New file for copying

		File myFile = new File(filepath);

		// 4.Copy screenshot to myfile

		FileUtils.copyFile(actualScreenshot, myFile);

	}

	public static Object[][] generateDataArray(List<String> dataList, int rowCount, int columnCount) {
		//columnCount = columnCount / rowCount;
		int k = 0;
		String[][] xlsData = new String[rowCount][columnCount];
		for (int i = 0; i < rowCount; i++) {

			for (int j = 0; j < columnCount; j++) {
				xlsData[i][j] = dataList.get(k++);

			}
		}
		return xlsData;
	}

	
	@DataProvider
	public static Object[][] provideDataFromCsv() throws IOException {

		FileReader fis = new FileReader("/Users/shreenivas_khedkar/Desktop/seleniumwork/SeleniumParatus/test/DDT/bmidata.csv");
		BufferedReader reader = new BufferedReader(fis);
		List<String> records = new ArrayList<String>();
		String line;
		int rowCount = 0;
		int colCount=0;
		while ((line = reader.readLine()) != null) {
			rowCount++;
			colCount=0;
			String[] tokens = line.split(",");

			for (int i = 0; i < tokens.length; i++) {
				records.add(tokens[i]);
				colCount++;
			}
		}

		return generateDataArray(records,rowCount,colCount);
	}
}

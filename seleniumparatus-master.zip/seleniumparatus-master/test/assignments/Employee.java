package assignments;

public class Employee {

	String name;
	int eno;
	
	public Employee(String name,int eno) {
		
		this.name=name;
		this.eno =eno;
		
	}
	
	public void printEmp(Employee e) {
		
		System.out.print(e.name+" "+e.eno);
	
	}
	
}

package assignments;

public class OMG {

	public static void main(String[] args) {

		String s1 = "Shree";
		
		String s2 = "shree";
		
		if(s1.equalsIgnoreCase(s2)) {
			
			System.out.println("Hi");
		}
		else {
			System.out.println("Bye");
		}
	}

}

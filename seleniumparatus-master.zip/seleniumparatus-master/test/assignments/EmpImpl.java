package assignments;

import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;

public class EmpImpl {

	public static void main(String[] args) {
		
		Employee e1 = new Employee("abc", 1);
		Employee e2 = new Employee("aaa", 2);
		Employee e3 = new Employee("aaa", 3);
		Employee e4 = new Employee("aaa", 4);
		Employee e5 = new Employee("aaa", 5);
		Employee e6 = new Employee("aaa", 6);
		Employee e7 = new Employee("xyz", 7);
		
		Set<Employee> empSet = new LinkedHashSet<Employee>();
		empSet.add(e1);
		empSet.add(e2);
		empSet.add(e3);
		empSet.add(e4);
		empSet.add(e5);
		empSet.add(e6);
		empSet.add(e7);
		
	    for (Employee e: empSet)
	    		e.printEmp(e);
		
		

	}

}

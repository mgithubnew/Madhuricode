package assignments;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class TripHobo {

	static WebDriver driver;
	static String urlName = "https://www.triphobo.com/";

	public static void main(String[] args) throws InterruptedException {
		
		
		System.setProperty("webdriver.chrome.driver", "/Users/shreenivas_khedkar/Downloads/chromedriver2.37/chromedriver");
		driver = new ChromeDriver();
		
		WebDriverWait wait = new WebDriverWait(driver, 20);
		
		driver.get(urlName);
		
		WebElement laterButton = wait.until(ExpectedConditions.elementToBeClickable(By.className("later-btn")));
		laterButton.click();
		wait.until(ExpectedConditions.presenceOfElementLocated(By.id("spl-autocomplete-search"))).sendKeys("houston");
		Thread.sleep(4000);
		
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//li/i[contains(text(),', Texas, United States, North America')]"))).click();
		wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText("Start Trip"))).click();
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//button[contains(text(),'Save & Let me Plan')]"))).click();
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[@id='js_close_hotel_combine']"))).click();
		wait.until(ExpectedConditions.presenceOfElementLocated(By.id("hotel_step_popup_skip_hotel"))).click();
		Thread.sleep(4000);
		
		wait.until(ExpectedConditions.elementToBeClickable(By.id("js_add_activity"))).click();
		
		WebElement houstonImageHover=wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//img[@alt='Space Center Houston']")));
		
		Actions builder = new Actions(driver);
		
		builder.moveToElement(houstonImageHover).build().perform();
		
		WebElement houstonImageClick = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//li[contains(@data-info,'Space Center Houston')]//i[@class='add-to-plan']")));
		houstonImageClick.click();

		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[@data-day=2]//label"))).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@data-unique-id='add_day_list_drawer']//a[@id='close']"))).click();
		Thread.sleep(4000);

		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@data-unique-id='activity_drawer']//a[@id='close']"))).click();
		Thread.sleep(4000);
		
		WebElement source = driver.findElement(By.xpath("//div[@class='step-2-attraction-details']/h4[@title='Space Center Houston']"));
		WebElement target = driver.findElement(By.xpath("//li[@data-day-id='3']//div[@id='js_end_of_day_container']"));
		
		builder.dragAndDrop(source, target).build().perform();
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".js_finish_planning_btn"))).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".fin-plan-btn"))).click();
		Thread.sleep(4000);

		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("js_view_trip_plan"))).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("js_right_day_scroll"))).click();
		
		System.out.println("Hurray!!! Your trip is planned successfully!!");
	}

}

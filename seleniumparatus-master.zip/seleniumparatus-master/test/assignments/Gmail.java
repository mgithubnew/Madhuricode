package assignments;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class Gmail {

	// Url : https://accounts.google.com/ServiceLogin
	// username : id :identifierId
	// nextButton: id : identifierNext
	// passwordbox: name: password
	// Next : id:passwordNext

	// data: everydaylearn4yourself
	// password
	WebDriver driver;
	WebDriverWait wait;

	@BeforeClass
	public void initialize() {

		System.setProperty("webdriver.gecko.driver", "/Users/shreenivas_khedkar/Downloads/geckodriver");
		driver = new FirefoxDriver();

		wait = new WebDriverWait(driver, 15);

	}

	@Test
	public void launchGmail() {

		driver.get("https://accounts.google.com/ServiceLogin");

	}

	@Test(dependsOnMethods = "launchGmail")
	public void enterUserName() {

		WebElement userName = driver.findElement(By.id("identifierId"));
		userName.sendKeys("everydaylearn4yourself");
	}

	@Test(dependsOnMethods = "enterUserName")
	public void enterNext() throws InterruptedException {

		WebElement nextButton = driver.findElement(By.id("identifierNext"));
		nextButton.click();

		Thread.sleep(3000);
	}

	@Test(dependsOnMethods = "enterNext")
	public void enterPassword() {

		driver.findElement(By.xpath("//input[@name='password']")).sendKeys("abc123");

		Actions builder = new Actions(driver);

		builder.sendKeys(Keys.ENTER).build().perform();
	}
}

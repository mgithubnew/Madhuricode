package Listeners;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.events.EventFiringWebDriver;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class CaptureActivity {

	WebDriver driver ;

	EventFiringWebDriver firingDriver ;
	
	@BeforeSuite
	public void init() throws InterruptedException {

		System.setProperty("webdriver.gecko.driver", "/Users/shreenivas_khedkar/Downloads/gecko20/geckodriver");
		driver = new FirefoxDriver();
		firingDriver = new EventFiringWebDriver(driver);
		

	}
	@BeforeTest
	public void testPreparation() throws InterruptedException {
	
		Listeners eventListener = new Listeners();
		firingDriver.register(eventListener);

		
		firingDriver.get("https://opensource-demo.orangehrmlive.com/");

		WebElement myAccount = firingDriver.findElement(By.id("txtUsername"));

		myAccount.sendKeys("Admin");

		WebElement password = firingDriver.findElement(By.id("txtPassword"));
		password.sendKeys("admin123");

		WebElement loginButton = firingDriver.findElement(By.id("btnLogin"));

		loginButton.click();

		Thread.sleep(7000);

		firingDriver.findElement(By.linkText("Admin")).click();

		Thread.sleep(7000);

		System.out.println("No. of clicks made :" + Listeners.clickCount);

	}

	

	@Test
	public void checkboxTest1() throws InterruptedException {
		
		
	}
	
	@Test
	public void checkboxTest() throws InterruptedException {
		
		WebElement checkbox = firingDriver.findElement(By.id("ohrmList_chkSelectRecord_24"));

		Thread.sleep(5000);
		if (checkbox.isDisplayed()) {
			checkbox.click();

		}
//		if (checkbox.isSelected()) {
//			checkbox.click();
//		}
		System.out.println("No. of clicks made :" + Listeners.clickCount);
	}
}

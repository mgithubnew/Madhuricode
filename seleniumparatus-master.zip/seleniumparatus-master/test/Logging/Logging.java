package Logging;

import org.apache.log4j.Logger;
import org.apache.log4j.xml.DOMConfigurator;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Logging {

	static Logger log = Logger.getLogger(Logging.class);
	
	static WebDriver driver;
	public static void main(String[] args) {
		
		DOMConfigurator.configure("/Users/shreenivas_khedkar/Desktop/seleniumwork/SeleniumParatus/log4j2.xml");
		log.info("Test Started");

		try {
			
			log.warn("Test Started without setproperties");
			System.setProperty("webdriver.gecko.driver", "/Users/shreenivas_khedkar/Downloads/gecko");
			log.info("Property is set now");
			driver = new FirefoxDriver();
		}
		catch(Exception e) {
			
			log.error("Exception Occured while opening browser"+e);
		}
		log.info("Test Ended");
		//log.trace("Test Started");
	}

}

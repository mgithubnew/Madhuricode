package Logging;

import org.apache.log4j.Logger;

public class LogExample {

	/* Get actual class name to be printed on */
	static Logger log = Logger.getLogger(LogExample.class.getName());

	public static void main(String[] args) {
		String a = "message";
		log.warn("Hello this is an info message:" + a);
		log.debug("Thi Is Debug Message");
	}

}

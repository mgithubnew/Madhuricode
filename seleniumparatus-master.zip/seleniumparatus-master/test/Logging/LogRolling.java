package Logging;

import org.apache.log4j.Logger;
import org.apache.log4j.xml.DOMConfigurator;

public class LogRolling {
	
	static Logger logger = Logger.getLogger(LogRolling.class);
	
	public static void main(String[] args) throws InterruptedException {
		DOMConfigurator.configure("log4j3.xml");
		
		for (int i = 0; i < 2000; i++) {
			logger.info("This is the " + i + " time I say 'Hello World'.");
			Thread.sleep(10);
		}
	}
}

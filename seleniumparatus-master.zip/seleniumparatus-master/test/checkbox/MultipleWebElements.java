package checkbox;

import static org.junit.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import java.util.List;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class MultipleWebElements {

	static WebDriver driver;

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {

		System.setProperty("webdriver.gecko.driver", "/Users/shreenivas_khedkar/Downloads/geckodriver");
		// Open browser
		driver = new FirefoxDriver();

		driver.get("http://cookbook.seleniumacademy.com/Config.html");
	}

//	@AfterClass
	public static void tearDownAfterClass() throws Exception {

		driver.quit();
	}

	@Test
	public void testCheckbox() {

		WebElement absCheckbox = driver.findElement(By.name("abs"));
		
				
		//Returns false if element is not selected.
//		if(!(absCheckbox.isSelected())) {
//			
//			absCheckbox.click();
//		}
//		
		
		assertEquals(false, absCheckbox.isSelected());
		absCheckbox.click();
		assertTrue(absCheckbox.isSelected());
	}

	@Test
	public void testRadioButton() {

		List<WebElement> radioButtons = driver.findElements(By.name("fuel_type"));
		
		
		 assertEquals(2, radioButtons.size());
			
		 
		 
		 for(int i =0 ;i<radioButtons.size();i++) {
			WebElement radioButton= radioButtons.get(i);
			
			if(radioButton.getText().equals("Petrol")|| radioButton.getText().equals("Diesel"))
			{
				System.out.println(radioButton.getText()+" option exists");
			
			}
			 
		 }
		
		
		
		
		for (WebElement radioButton : radioButtons) {
			if ("Petrol".equals(radioButton.getAttribute("value"))) {
				radioButton.click();

				assertTrue(radioButton.isSelected());
				break;
			}
		}

	}

	//@Test
	public void testComboBox() {

		Select dropDown = new Select(driver.findElement(By.name("make")));

		dropDown.selectByIndex(0);
		dropDown.selectByIndex(1);
		dropDown.selectByValue("mercedes");
		dropDown.selectByVisibleText("Audi");

		assertEquals(4, dropDown.getOptions().size());

		List<WebElement> dropDownOptions = dropDown.getOptions();

		for (WebElement dropDownOption : dropDownOptions) {

			System.out.println(dropDownOption.getText());
		}
	}

	//@Test
	public void testMultiSelectDropDown() {

		Select dropDown = new Select(driver.findElement(By.name("color")));

		
		assertEquals(5, dropDown.getOptions().size());
		assertTrue(dropDown.isMultiple());

		//dropDown.selectByIndex(0);
		dropDown.selectByIndex(1);
		dropDown.selectByIndex(2);
		dropDown.selectByIndex(3);
		dropDown.selectByVisibleText("");
		dropDown.deselectAll();
		dropDown.deselectByIndex(0);
	

		// assertEquals(4, dropDown.getOptions().size());

		List<WebElement> dropDownOptions = dropDown.getAllSelectedOptions();

		String [] actualOptions = new String[5];
		for (int i=0;i<dropDownOptions.size();i++) {

			String option=dropDownOptions.get(i).getText();
			actualOptions[i]= option;
			
		}

		dropDown.getAllSelectedOptions();
		
		//List of options 
		
		String [] expectedOptions = {"Black","White"};
		
	// list of options -> text
		
	}
}

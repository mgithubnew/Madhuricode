package alert;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class MultipleWebElements {

	static WebDriver driver;
	static WebDriverWait wait;

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {

		System.setProperty("webdriver.gecko.driver", "/Users/shreenivas_khedkar/Downloads/geckodriver");
		// Open browser
		driver = new FirefoxDriver();

		driver.get("http://cookbook.seleniumacademy.com/Alerts.html");

		wait = new WebDriverWait(driver, 15);

	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {

		driver.close();

	}

	// @Test
	public void testAlert() throws InterruptedException {

		WebElement showAlertBox = driver.findElement(By.id("simple"));

		showAlertBox.click();

		Alert alertBox = driver.switchTo().alert();

		// Thread.sleep(4000);

		wait.until(ExpectedConditions.alertIsPresent());
		alertBox.accept(); // ok

	}

	// @Test
	public void testAlertOkCancel() throws InterruptedException {

		WebElement showAlertBox = driver.findElement(By.id("confirm"));

		showAlertBox.click();

		Alert alertBox = driver.switchTo().alert();

		System.out.println(alertBox.getText());

		Thread.sleep(4000);

		alertBox.dismiss();// cancel

	}

	// @Test
	public void testAlertInputText() throws InterruptedException {

		WebElement showAlertBox = driver.findElement(By.id("prompt"));

		showAlertBox.click();

		Alert alertBox = driver.switchTo().alert();

		Thread.sleep(4000);
		// assertEquals("Harry Potter", alertBox.getText());

		// alertBox.sendKeys("");

		alertBox.sendKeys("Parry Hotter");

		Thread.sleep(4000);
		// alertBox.sendKeys("abcd");

	}

	@Test
	public void testWindow() {

		driver.get("http://cookbook.seleniumacademy.com/Config.html");
		// Click to open the window
		driver.findElement(By.id("helpbutton")).click();

		// Parent Window Handle
		String parentWindow = driver.getWindowHandle();
		
		Set<String> windowHandles = driver.getWindowHandles();

		// How many windows are opened.
		System.out.println("Windows Opened:"+windowHandles.size());
		
		ArrayList<String> windowsList = new ArrayList<>(windowHandles) ;
		
		String chidlWindowName = windowsList.get(1);
		
		driver.switchTo().window(chidlWindowName);
		

//		for (String windowHandle : windowHandles) {
//
//			System.out.println(driver.switchTo().window(windowHandle).getTitle());
//
//		}

		// List<String> windowHandleList = new ArrayList<String>(windowHandles);
		//
		// windowHandleList.get(1);
		//

		// Build my car...Get the title of parent Window
		System.out.println(driver.getTitle());

		// Switching from parent window to Help window
//		driver.switchTo().window("HelpWindow");
//
//		// Printing the title of child window
//		System.out.println(driver.getTitle());
//
//		// Switch back to parent Window
//		driver.switchTo().window(parentWindow);
//
//		// Print title of Parent window
//		System.out.println(driver.getTitle());
	}

	//@Test
	public void testFrame() {

		driver.navigate().to("http://cookbook.seleniumacademy.com/Frames.html");

		
		List<WebElement> frames = driver.findElements(By.tagName("frame"));

		// for(WebElement frame : frames ) {

		System.out.println(frames.size());
		// }

		driver.switchTo().frame("left");
		driver.switchTo().frame(frames.get(1));
		
		WebElement element  = driver.findElement(By.xpath("/html/body/p"));
		
		driver.switchTo().frame(element);
		
		
		System.out.println(driver.findElement(By.xpath("/html/body/p")).getText());
		
		driver.findElement(By.xpath("locator of checkbox")).click();
		driver.switchTo().parentFrame();
		
		driver.switchTo().frame("right");
		
		System.out.println(driver.findElement(By.xpath("/html/body/p")).getText());
		
		driver.switchTo().parentFrame();
		driver.switchTo().frame(frames.get(1));
		
		System.out.println(driver.findElement(By.xpath("/html/body/p")).getText());
//
//		//driver.switchTo().frame("left");
//		driver.switchTo().frame(frames.get(1));
//		System.out.println(driver.findElement(By.xpath("/html/body/p")).getText());
//		driver.switchTo().parentFrame();
//		driver.switchTo().frame(frames.get(2));
//		System.out.println(driver.findElement(By.xpath("/html/body/p")).getText());

	}

	// @Test
	public void testSystemPopup() throws AWTException, InterruptedException {

		driver.navigate().to("http://toolsqa.com/automation-practice-form/");

		driver.findElement(By.id("photo")).click();

		// File Need to be imported

		File file = new File("/Users/shreenivas_khedkar/Downloads/Love_files/test.jpg");

		StringSelection stringSelection = new StringSelection(file.getAbsolutePath());

		Toolkit.getDefaultToolkit().getSystemClipboard().setContents(stringSelection, null);

		Robot robot = new Robot();

		// Cmd + Tab is needed since it launches a Java app and the browser looses focus

		//

		// Open Goto window

		robot.keyPress(KeyEvent.VK_META);

		robot.keyPress(KeyEvent.VK_SHIFT);

		robot.keyPress(KeyEvent.VK_G);

		robot.keyRelease(KeyEvent.VK_META);

		robot.keyRelease(KeyEvent.VK_SHIFT);

		robot.keyRelease(KeyEvent.VK_G);

		// Paste the clipboard value

		robot.keyPress(KeyEvent.VK_META);

		robot.keyPress(KeyEvent.VK_V);

		robot.keyRelease(KeyEvent.VK_META);

		robot.keyRelease(KeyEvent.VK_V);

		// Press Enter key to close the Goto window and Upload window

		robot.keyPress(KeyEvent.VK_ENTER);

		robot.keyRelease(KeyEvent.VK_ENTER);

		robot.delay(500);

		robot.keyPress(KeyEvent.VK_ENTER);

		robot.keyRelease(KeyEvent.VK_ENTER);
	}

}

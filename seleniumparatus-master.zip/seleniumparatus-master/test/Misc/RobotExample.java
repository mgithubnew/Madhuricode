package Misc;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.io.File;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

public class RobotExample {

	WebDriver driver;

	@BeforeSuite
	public void init() throws InterruptedException {

		System.setProperty("webdriver.gecko.driver", "/Users/shreenivas_khedkar/Downloads/gecko20/geckodriver");
		// Open browser
		driver = new FirefoxDriver();

		driver.get("http://toolsqa.com/automation-practice-form/");
		
		Thread.sleep(3000);
		WebDriverWait wait = new WebDriverWait(driver, 10);
		
		WebElement photo = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@type='file']")));

		
		JavascriptExecutor executor = (JavascriptExecutor) driver;
		executor.executeScript("arguments[0].click();", photo);


	}

	//@Test
	public void uploadTestWindows() throws AWTException, InterruptedException {

		
		WebDriverWait wait = new WebDriverWait(driver, 10);

		WebElement photo = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@type='file']")));

		JavascriptExecutor executor = (JavascriptExecutor) driver;
		executor.executeScript("arguments[0].click();", photo);

		// Create object of Robot class
		Robot robot = new Robot();
		Thread.sleep(1000);

		// Press Enter
		robot.keyPress(KeyEvent.VK_ENTER);

		// Release Enter
		robot.keyRelease(KeyEvent.VK_ENTER);

		// Press CTRL+V
		robot.keyPress(KeyEvent.VK_CONTROL);
		robot.keyPress(KeyEvent.VK_V);

		// Release CTRL+V
		robot.keyRelease(KeyEvent.VK_CONTROL);
		robot.keyRelease(KeyEvent.VK_V);
		Thread.sleep(1000);

		// Press Enter
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);

	}

	//@Test
	public void uploadTest() throws InterruptedException, AWTException {

		
		// 1.File Need to be imported

		File file = new File("/Users/shreenivas_khedkar/Desktop/seleniumwork/collection.png");

		StringSelection stringSelection = new StringSelection(file.getAbsolutePath());

		// 2.Copy to clipboard

		Toolkit.getDefaultToolkit().getSystemClipboard().setContents(stringSelection, null);

		Robot robot = new Robot();

		// Cmd + Tab is needed since it launches a Java app and the browser looses focus

		robot.keyPress(KeyEvent.VK_META);

		robot.keyPress(KeyEvent.VK_TAB);

		robot.keyRelease(KeyEvent.VK_META);

		robot.keyRelease(KeyEvent.VK_TAB);

		robot.delay(500);

		// Open Goto window

		robot.keyPress(KeyEvent.VK_META);

		robot.keyPress(KeyEvent.VK_SHIFT);

		robot.keyPress(KeyEvent.VK_G);

		robot.keyRelease(KeyEvent.VK_META);

		robot.keyRelease(KeyEvent.VK_SHIFT);

		robot.keyRelease(KeyEvent.VK_G);

		// Paste the clipboard value

		robot.keyPress(KeyEvent.VK_META);

		robot.keyPress(KeyEvent.VK_V);

		robot.keyRelease(KeyEvent.VK_META);

		robot.keyRelease(KeyEvent.VK_V);

		// Press Enter key to close the Goto window and Upload window
		robot.delay(2000);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
//		robot.delay(500);
//		robot.keyPress(KeyEvent.VK_ENTER);
//		robot.keyRelease(KeyEvent.VK_ENTER);
	}
	
	@Test
	public void uploadFileWithoutRobot() {
		
		
		driver.findElement(By.id("photo")).sendKeys("/Users/shreenivas_khedkar/Documents/ECN.pdf");
		
	}

}

package classAssignments;

public class Animal {
	
	String color;
	
	public void run() {
		
		System.out.println("Animal can run");
	}

}

package classAssignments;

public class CalculatorImpl {

	public static void main(String[] args) {
		
	SimpleCalculator sc = new SimpleCalculator();
	sc.addition(10, 20);
	sc.substraction(10, 20);
	
	SciCalculator sci = new SciCalculator();
	sci.addition(10, 20);
	sci.substraction(10, 20);
	
	Calculator c = new SimpleCalculator();
	Calculator c1= new SciCalculator();
	//Calculator c2 = new Calculator();
	}

}

package classAssignments;

public class Lion extends Animal {

	public void roar() {

		System.out.println("Lion can roar!");
	}

	public void run() {

		System.out.println("Lion can run");
	}

}

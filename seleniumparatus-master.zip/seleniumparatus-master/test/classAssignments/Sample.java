package classAssignments;

public abstract class Sample {

	abstract void sampleTest();
	
	public void test() {
		
		
	}
		
}

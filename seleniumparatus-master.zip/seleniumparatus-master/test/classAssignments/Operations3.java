package classAssignments;

public interface Operations3 extends Operations2,Operations {
	
	public void addition();
	public void substraction();
	public void division();
	public void multiplication();
	

}

package classAssignments;

public class Manager extends Employee { // child class or inherited class or subclass

	int noOfReportees;

	public void doAppraisal() {

		System.out.println("Appraisals to favourites!");
		System.out.println("No Appraisal!");
	}

	public static void main(String[] args) {

		Manager m = new Manager();

		m.designation = "Manager";
		m.salary = 1111.1111;
		m.eno = 2;
		m.name = "xyz";
		m.noOfReportees = 10;
		m.printEmployee();
		m.doAppraisal();

		Employee e = new Employee();
		
		e.designation = "Worker";
		e.eno =1 ;
		e.salary = 11;
		e.name ="abc";
		
		Employee e1 = new Manager();//
		
		
	}

}

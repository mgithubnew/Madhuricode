package classAssignments;

public class Employee { //base class or root class
	
	String name;
	String designation;
	int eno;
	double salary;
	

	void printEmployee() {
		
		System.out.println("Employee Details");
	}
	
	
	public void doAppraisal() {
		
		System.out.println("Employee can do self appriasal");
	}

}

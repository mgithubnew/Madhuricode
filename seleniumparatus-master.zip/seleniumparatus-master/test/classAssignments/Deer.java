package classAssignments;

public class Deer extends Animal{

	
	public void jump() {
		System.out.println("Deer can Jump!");
	}
	
	public void run() {
		
		System.out.println("Deer can run fast!");
	}
}

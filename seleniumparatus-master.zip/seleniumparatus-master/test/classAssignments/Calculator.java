package classAssignments;

public abstract class Calculator {

	int a =10;
	public void addition(int a , int b) {
		
		int result = a+b;
	}

	public void addition(int a, int b, int c) {
		
		int result = a+b+c;
	}
	public void substraction(int a , int b) {
		
		int result = a-b;
	}
	
	 abstract void calculate();
}

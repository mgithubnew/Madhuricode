package classAssignments;

public class ScientificCalculator  implements Operations {

	int a,b;
	public void sin() {

		System.out.println("sin:" + Math.sin(a));
	}
	@Override
	public void addition() {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void substraction() {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void division() {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void multiplication() {
		// TODO Auto-generated method stub
		
	}

}

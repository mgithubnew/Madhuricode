package classAssignments;

public class AnimalImplementation {

	public static void main(String[] args) {

//		Animal a = new Animal();
//		a.color = "no color";
//		a.run();// Animal Can run
//		
//		Lion l = new Lion();
//		l.color = "Brown";
//		l.roar(); // Lion can roar
//		l.run();  //Animal can run
		
		
		Animal a2 = new Lion(); // Base class object (reference) 
		                         //can hold a reference of child class
		
       //a2 object can see/access the things that Animal class has.(*)
		//a2.roar();//Error
		a2.run();  //lion can run
		a2.color="";
		
		
		a2 = new Deer();
		a2.run();
		
	}

}

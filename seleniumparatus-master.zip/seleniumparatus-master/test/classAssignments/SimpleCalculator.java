package classAssignments;

public class SimpleCalculator extends Calculator{

	@Override
	void calculate() {
		// TODO Auto-generated method stub
		
	}



	
	
}

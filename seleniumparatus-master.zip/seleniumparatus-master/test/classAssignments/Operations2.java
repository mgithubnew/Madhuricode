package classAssignments;

public interface Operations2 {
	
	public void addition();
	public void substraction();
	public void division();
	public void multiplication();
	

}

package classAssignments;

public class SciCalculator extends Calculator {

	public void addition(int a , int b) {
		
		
	}

	@Override
	void calculate() {
		// TODO Auto-generated method stub
		
	}

}

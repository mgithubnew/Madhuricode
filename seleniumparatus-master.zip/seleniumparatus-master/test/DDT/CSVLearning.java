package DDT;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import common.Constants;
import common.LocatorHelper;
import common.Utilities;
import common.Verification;

public class CSVLearning {

	Properties prop;
	WebDriver driver;
	Object[][] bmiData;

	static Logger log = Logger.getLogger(CSVLearning.class);

	@BeforeClass
	public void init() {

		System.setProperty("webdriver.chrome.driver",
				"/Users/shreenivas_khedkar/Downloads/chrome");
		log.info("System properties are set..");

		try {
			driver = new ChromeDriver();
			log.info("Chrome browser launched");
			prop = new Properties();
			InputStream inStream = new FileInputStream(
					"/Users/shreenivas_khedkar/Desktop/seleniumwork/SeleniumParatus/test/DDT/config.properties");
			prop.load(inStream);
			log.debug("config.properties loaded");
			driver.get(prop.getProperty("url"));
			log.info("URL is opened:"+prop.getProperty("url"));
		} catch (Exception e) {
			
			log.error("Exception occured:"+e);
		}
		 //Utilities.readCsv("/Users/shreenivas_khedkar/Desktop/seleniumwork/SeleniumParatus/test/DDT/bmidata.csv");
	}

	@Test(dataProviderClass = Utilities.class, dataProvider = "provideDataFromCsv")
	public void should_calculate_bmi(String heightValue, String weightValue, String bmiValue, String bmicategoryValue)
			throws InterruptedException {

		log.info("Test case(should_calculate_bmi)started...");
		
		try {
		WebElement height = inputHeight(heightValue);
		WebElement weight = inputWeight(weightValue);
		clickCalculate();
		waitForExecution();
		verifyBMI(bmiValue);
		verifyBMICategory(bmicategoryValue);
		clearInputs(height, weight);
		
		logSuccessfulExecution();
		}
		catch (Exception e) {
			log.error("Exception occured in test: "+e);
		}
	}

	private void logSuccessfulExecution() {
		log.debug("Height and weight textboxes are cleared");
		log.info("Test Case Execution Completed");
	}

	private void waitForExecution() throws InterruptedException {
		Thread.sleep(4000);
	}

	private void clearInputs(WebElement height, WebElement weight) {
		height.clear();
		weight.clear();
	}

	private void verifyBMICategory(String bmicategoryValue) {
		WebElement bmicategory = driver.findElement(LocatorHelper.getLocator(prop.getProperty("bmicategory")));
		Verification.textEquals(bmicategory.getAttribute("value"), bmicategoryValue);
		log.info("Verification of bmi category is completed");
	}

	private void verifyBMI(String bmiValue) {
		WebElement bmi = driver.findElement(LocatorHelper.getLocator(prop.getProperty("bmi")));
		Verification.textEquals(bmi.getAttribute("value"), bmiValue);
		log.info(Constants.VERIFICATION_BMI_LOG);
	}

	private void clickCalculate() {
		driver.findElement(LocatorHelper.getLocator(prop.getProperty("calculate"))).click();
		log.trace("Clicked on calculate");
	}

	private WebElement inputWeight(String weightValue) {
		WebElement weight = driver.findElement(LocatorHelper.getLocator(prop.getProperty("weight")));
		log.trace("WebElement weight is located");
		weight.sendKeys(weightValue);
		return weight;
	}

	private WebElement inputHeight(String heightValue) {
		WebElement height = driver.findElement(LocatorHelper.getLocator(prop.getProperty("height")));
		log.trace("WebElement height is located");
		height.sendKeys(heightValue);
		return height;
	}

}

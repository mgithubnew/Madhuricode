package DDT;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import common.Utilities;

public class DatabaseLearning {

	WebDriver driver;
	List<String> data;

	@BeforeSuite
	public void init() throws SQLException, ClassNotFoundException {

		System.setProperty("webdriver.chrome.driver",
				"/Users/shreenivas_khedkar/Downloads/chromedriver2.37/chromedriver");

		String dbUrl = "jdbc:mysql://127.0.0.1:3306/seldb";

		String username = "root";
		String password = "Zebra@123";
		String query = "select *  from Credentials;";
		Class.forName("com.mysql.jdbc.Driver");
		Connection con = DriverManager.getConnection(dbUrl, username, password);

		Statement stmt = con.createStatement();
		ResultSet rs = stmt.executeQuery(query);

		// ResultSetMetaData rsMetaData = rs.getMetaData();

		// rsMetaData.getColumnCount();

		int rowCount = 0;
		int colCount = 2;
		data = new ArrayList<String>();
		while (rs.next()) {
			data.add(rs.getString(2));
			data.add(rs.getString(3));
			rowCount++;
		}
		Object[][] loginData = Utilities.generateDataArray(data, rowCount, colCount);
	}

	@Test
	public void data() {
		System.out.println(data);
		System.out.println("Hello");
		System.out.println("HelloAd");
	}

}

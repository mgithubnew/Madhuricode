package Grid;

import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class SampleGrid {

	WebDriver driver ;
	
	@Test(dataProvider="provideData")
	public void launchURL(final String browserName, final String url ) throws MalformedURLException {
		String baseUrl = "http://192.168.0.102:4445/wd/hub";
		DesiredCapabilities capabilities = new DesiredCapabilities();

		capabilities.setBrowserName(browserName);
		
		
		driver = new RemoteWebDriver( new URL(baseUrl), capabilities);
		
		driver.get(url);
		
		//driver.close();
	}
	
	@DataProvider(parallel=true)
	public Object[][] provideData() {
		
		Object data[][] = new Object [2][2];
		
		data[0][0] ="firefox";
		data[0][1] ="https://www.amazon.in/";
		
		data[1][0] ="chrome";
		data[1][1] ="https://www.flipkart.com/";
		
//		data[2][0] ="internet explorer";
//		data[2][1] ="https://www.facebook.com/";
		
		
		return data;
		
	}

}

package Grid;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class SelfAssesment {

	public static void main(String[] args) {

		System.setProperty("webdriver.gecko.driver", "/Users/shreenivas_khedkar/Downloads/geckodriver");
		
		WebDriver driver1 = new FirefoxDriver();
		WebDriver driver2 = new ChromeDriver();
		
		
		driver1.findElement(By.id("id")).click();
		driver2.findElement(By.id("id")).click();
		
	}

}

package testNG;

import org.testng.annotations.Test;

public class ShoppingCart extends LogIn{
  @Test(dependsOnMethods="enterLogin",groups="Regression")
  public void addToCart() {
	 
	  System.out.println("Item added to cart");
  }
  
  @Test(groups="sanity",dependsOnMethods="enterLogin")
  public void  viewCart() {
	  System.out.println("Checking cart details");
  }
  @Test(dependsOnMethods="viewCart",groups="Regression")
  public void cancelCart() {
	  System.out.println("Cancel cart");
  }
  
  @Test(dependsOnGroups="Regression",groups="endtoend")
  public void checkOutCart() {
	  System.out.println("Cancel cart");
  }
  
}

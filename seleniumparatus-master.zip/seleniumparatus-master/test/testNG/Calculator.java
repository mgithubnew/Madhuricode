package testNG;

public class Calculator {

	public int addition(int value1, int value2) {

		return value1 + value2;
	}

	public int substraction(int value1, int value2) {

		return value1 - value2;
	}
}

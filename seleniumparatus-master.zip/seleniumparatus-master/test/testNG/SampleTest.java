package testNG;

import org.openqa.selenium.NoSuchElementException;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class SampleTest {
	
	
	@Test
	public void testMe() {
		
		System.out.println("Hi");
	}

	@Test(expectedExceptions=NoSuchElementException.class)
	public void testYou() {
		
		System.out.println("Bye");
		//throw new NoSuchElementException("Element not found");
	}

	
	@Parameters({"food"})
	@Test
	public void feedMe(@Optional(value="pavbhaji")String food) {
		
		System.out.println("Bye");
		System.out.println("My food is:"+food);
		//throw new NoSuchElementException("Element not found");
	}
}

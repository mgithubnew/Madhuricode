package testNG;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class NewTestSample {

	WebDriver driver;

	@Parameters({ "browser", "username", "password" })
	@Test
	public void f(String browserName, String username, String password) {
		System.out.println(browserName);

		switch (browserName) {

		case "chrome":
			System.setProperty("", "");
			driver = new ChromeDriver();
			break;

		case "firefox":
			System.setProperty("", "");
			driver = new FirefoxDriver();
			break;

		}
		System.out.println(username);
		System.out.println(password);

	}
		
}

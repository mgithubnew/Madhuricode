package testNG;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class TestNGSample {

	WebDriver driver = null;

	@BeforeClass
	public void prepareTest() {

		System.out.println("In Before Class1");
		System.setProperty("webdriver.gecko.driver", "/Users/shreenivas_khedkar/Downloads/geckodriver");
		//driver = new FirefoxDriver();
	}
	@BeforeMethod
	public void prepareData(){
	
	System.out.println("In prepare data");
	}
	
	@Test(priority=1)
	public void exceptionDemo() {
	
//		int a =10;
//		int b =0;
//		
//		int c =a/b;
		System.out.println("In exceptionDemo");
		}
	@Test(priority=2)
	public void launch() {

		// driver.get("https://www.wikipedia.org");
		System.out.println("In launch");
	}

	//@Test(dependsOnMethods = "launch")
	public void clickOnEnglishLink() {

		// driver.findElement(By.id("js-link-box-en")).click();
		System.out.println("clickOnEnglishLink");
	}

	//@Test(dependsOnMethods = "clickOnEnglishLink",  description = "This test is to put input in search box")
	public void searchSelenium() {

		driver.findElement(By.id("searchInput1")).sendKeys("Selenium");
		System.out.println("searchSelenium");
	}

	
	
	@AfterClass
	public void tearDown() {
		System.out.println("In After Class");
		// driver.quit();
	}
}

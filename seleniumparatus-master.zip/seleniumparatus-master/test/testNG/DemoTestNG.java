package testNG;

import org.openqa.selenium.NoSuchElementException;
import org.testng.annotations.Test;

public class DemoTestNG {
	
	@Test(expectedExceptions=NoSuchElementException.class)
	public void substraction() {
		
		System.out.println("Substraction Test Passed");
	}
	@Test
	public void addition() {

		System.out.println("Addition Test Passed");
	}

}

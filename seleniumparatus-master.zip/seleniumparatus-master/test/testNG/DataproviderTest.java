package testNG;

import org.testng.annotations.Test;
import org.testng.annotations.DataProvider;

public class DataproviderTest {

	@Test(dataProvider = "testData")
	public void login(String username,String password) {

		System.out.println(username);
		System.out.println(password);
		
	}

	@DataProvider
	public Object[][] testData() {

		Object[][] data = new Object[2][2];

		data[0][0] = "Sachin";
		data[0][1] = "Tendulkar";
		data[1][0] = "Rahul";
		data[1][1] = "Dravid";
		
		return data;

	}
}

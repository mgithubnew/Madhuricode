package testNG;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class MyTestNGTests {
	
	WebDriver driver;
	
	@Parameters({"URL","Browser"})
	@Test(groups= {"Regression"})
	public void mytest(String url,String browser) {

		System.out.println("Url:"+url);
		System.out.println("Url:"+browser);
		System.out.println("In MyTest");
	}

	@Test(groups="E2E")
	public void mytest2() {

		System.out.println("In MyTest2");
	}

	@Parameters("Browser")
	@Test(groups="Regression")
	public void mytest3(String browserName) {

		System.out.println("BrowserName:"+browserName);
		browserName ="Chrome";
		switch(browserName) {
		
		case "FireFox" :
			System.setProperty("webdriver.gecko.driver", "/Users/shreenivas_khedkar/Downloads/geckodriver");
			driver = new FirefoxDriver();
			break;
			
		case "Chrome" :
			System.setProperty("webdriver.gecko.driver", "/Users/shreenivas_khedkar/Downloads/geckodriver");
			driver = new ChromeDriver();
			break;
				
		}
		System.out.println("In MyTest3");
	}
	
	@Test(groups="E2E")
	public void mytest4() {

		System.out.println("In MyTest4");
	}
}

package testNG;

import org.testng.annotations.Test;

public class LogIn {
  @Test(groups="sanity")
  public void launch() {
	 
	  System.out.println("amazon is launched");
  }
  
  @Test(dependsOnMethods="launch",groups="sanity")
  public void enterUsername() {
	  System.out.println("Username is entered");
  }
  @Test(dependsOnMethods= {"enterUsername"},groups="sanity")
  public void enterPassword() {
	  System.out.println("Password is entered");
  }
  
  @Test(dependsOnMethods= {"enterPassword"},groups="sanity")
  public void enterLogin() {
	  System.out.println("Clicked on log in");
  }
  
}

package testNG;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;

import static org.testng.Assert.assertEquals;

import org.testng.annotations.AfterClass;

public class NewTest {

	@Test(groups="Regression")
	public void f1() {
		System.out.println("In f1");
		
		assertEquals("Selenium", "Selenium");
	}

	@Test
	public void f2() {
		System.out.println("In f2");
	}

	@Test(groups="Regression")
	public void f3() {
		System.out.println("In f3");
	}

	@Parameters({"Browser"})
	@Test
	public void login(String browserName) {
		System.out.println("In f3:"+browserName);
	}
	@BeforeClass
	public void beforeClass() {
	}

	@AfterClass
	public void afterClass() {
	}

}

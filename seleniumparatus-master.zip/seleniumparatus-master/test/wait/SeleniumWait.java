package wait;

import org.testng.annotations.Test;

import common.Constants;
import common.Waits;

import org.testng.annotations.BeforeClass;

import static org.testng.Assert.assertEquals;

import java.util.concurrent.TimeUnit;
import java.util.function.Function;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterClass;

public class SeleniumWait {

	WebDriver driver;

	WebDriverWait wait;

	@Test
	public void testDynamicallyLoadedElement() throws InterruptedException {

		// Constants c = new Constants();

		driver.findElement(By.xpath("//div[@id='start']/button")).click();

		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id ='finish']/h4")));
		String text = driver.findElement(By.xpath("//*[@id ='finish']/h4")).getText();

		assertEquals(text, "Hello World!");

	}

	@BeforeClass
	public void beforeClass() {
		System.setProperty("webdriver.gecko.driver", "/Users/shreenivas_khedkar/Downloads/geckodriver");
		// Open browser
		driver = new FirefoxDriver();

		driver.get("http://the-internet.herokuapp.com/dynamic_loading/1");

		// driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);

		wait = new WebDriverWait(driver, 15);

	}

	@AfterClass
	public void afterClass() {
		
		Wait wait  = new FluentWait(driver).withTimeout(10, TimeUnit.SECONDS)
					.ignoring(Exception.class).pollingEvery(200, TimeUnit.MILLISECONDS);
		
		wait.until(new Function<WebDriver, WebElement>() {

			@Override
			public WebElement apply(WebDriver driver) {
				return driver.findElement(By.id("identifier"));
			}
			
		});
		
	}

}
